# NM1130 — AI & Digital Skills Practical Portfolio

**Naan Mudhalvan | University College of Engineering (BIT Campus), Anna University, Tiruchirappalli**  
**Department:** CSE (AI & ML) · **Academic Year:** 2026–2027 · **Semester:** III

## About this repository

This portfolio brings together eight small Python practicals covering AI concepts, productivity tools, real-world applications, professional branding, cybersecurity, Git fundamentals, data analysis, and career planning. Each script includes an explanation of its purpose and produces readable console output.

## Practical index

| Ex. No. | Topic | Python file | Main learning outcome |
|---:|---|---|---|
| 1 | AI Fluency | [`01.ai_fluency.py`](01.ai_fluency.py) | Explore AI history, classification, regression, clustering, optimization, neural networks, and basic NLP. |
| 2 | AI Productivity | [`02.ai_productivity.py`](02.ai_productivity.py) | Practise drafting, summarising, extracting action items, and generating sales insights. |
| 3 | AI Applications | [`03.ai_applications.py`](03.ai_applications.py) | Demonstrate AI use cases in healthcare, banking, recommendations, and agriculture. |
| 4 | LinkedIn Profile Analyzer | [`04.linkedin_profile_analyzer.py`](04.linkedin_profile_analyzer.py) | Review a profile, generate headline ideas, and visualise profile improvements. |
| 5 | Cybersecurity Toolkit | [`05.cybersecurity_toolkit.py`](05.cybersecurity_toolkit.py) | Try password checks, secure password generation, hashing, phishing URL checks, and integrity tools. |
| 6 | Mini Git | [`06.mini_git.py`](06.mini_git.py) | Learn commit, branch, merge, conflict, clone, push, and pull-request concepts. |
| 7 | Power BI Data Preparation | [`07.power_bi_dashboard.py`](07.power_bi_dashboard.py) | Prepare sales data, calculate useful metrics, and create dashboard-ready CSV files. |
| 8 | Career Essentials | [`08.career_essentials.py`](08.career_essentials.py) | Assess skills, identify gaps, set SMART goals, and prioritise tasks. |

## Setup and execution

Use Python 3.10 or newer.

1. Download or clone this repository.
2. Open a terminal in the repository folder.
3. Install the required packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Run the practical you want to explore. For example:

   ```bash
   python 01.ai_fluency.py
   python 04.linkedin_profile_analyzer.py
   python 07.power_bi_dashboard.py
   python 08.career_essentials.py --interactive
   ```

On Windows, use `py` instead of `python` if that is how Python is configured on your computer.

## Supporting files

- `04.profile_improvement.png` — sample profile-improvement visual.
- `07.sales_raw.csv` — sample sales data before cleaning.
- `07.sales_clean.csv` — cleaned sales data for Power BI.
- `07.sales_dashboard.png` — sample sales dashboard visual.
- `08.career_skills_radar.png` — sample career-skills radar chart.

Some scripts may regenerate charts or CSV files when run. Check each script's output messages for details.

## Personalisation note

To make your own learning record distinct, add a short note about what you learned from each practical, include your own sample inputs where appropriate, and record any changes you made. Keep the experiment objectives intact and verify that all filenames and README links match the files in your repository.
